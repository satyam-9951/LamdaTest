package unqork.tests;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface CustomTest {
	String author() default "";
    String category() default "";
	String story() default "";
	String sprint() default "";
}
