package unqork.base;

import java.awt.Desktop;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.google.gson.JsonObject;

import io.github.bonigarcia.wdm.WebDriverManager;
import unqork.pages.AdminPage;
import unqork.pages.ForgotPasswordPage;
import unqork.pages.HomePage;
import unqork.pages.LoginPage;
import unqork.pages.QuotePage;
import unqork.tests.CustomTest;

public class Base {

	private static final Logger logger = LogManager.getLogger(Base.class);
    public static ExtentReports extent;
    public static ExtentTest test;
	public static WebDriver driver;
	public JsonObject jsonObject;
	public Properties properties;
	private final JsonDataConverter converter = new JsonDataConverter();
	public LoginPage loginPage;
	public ForgotPasswordPage forgotPasswordPage;
	public HomePage homePage;
	public QuotePage quotePage;
	public AdminPage adminPage;
	
	private static final String EXTENT_RESULTS_DIR = "reports";
	private static final String SCREENSHOTS_DIR = "reports/screenshots";

	@BeforeSuite(alwaysRun = true)
	public void getWebDriver() {
//		driver = new ChromeDriver();
//		properties = new Properties();
//		loginPage = new LoginPage(driver);
//		forgotPasswordPage = new ForgotPasswordPage(driver);
//		homePage = new HomePage(driver);
//		adminPage = new AdminPage(driver);
//		quotePage=new QuotePage(driver);
		Properties properties = new Properties();
		FileReader fileReader;
		try {
			fileReader = new FileReader(
					System.getProperty("user.dir") + "/src/test/resources/config/unqork.properties");
            properties.load(fileReader);
            System.out.println("this is the unqork property"+properties.getProperty("unqork"));
			jsonObject = converter.getJsonObject(properties.getProperty("unqork"));
			fileReader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		 logger.info("Cleaning Allure results directory...");
       try {
           Files.walk(Paths.get(SCREENSHOTS_DIR))
                   .map(Path::toFile)
                   .forEach(File::delete);
       } catch (Exception e) {
           logger.error("Failed to clean Extent results directory", e);
       }

	}
	@BeforeMethod
	public void setup(Method method) {
//		WebDriverManager.chromedriver().setup();
//		WebDriver driver = new ChromeDriver();
		driver = new ChromeDriver();
		properties = new Properties();
		loginPage = new LoginPage(driver);
		forgotPasswordPage = new ForgotPasswordPage(driver);
		homePage = new HomePage(driver);
		adminPage = new AdminPage(driver);
		quotePage=new QuotePage(driver);
		driver.manage().window().maximize();
		driver.get("https://trainingx.unqork.io/#/display/67545b82c5a4314c973256aa");
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
//		System.out.println(Thread.currentThread().getName());
		test = extent.createTest(extractAndSetTestName(method),extractAndSetTestDescription(method)).assignAuthor(extractAndSetTestAuthor(method)).assignCategory(extractAndSetTestCategory(method));

	}
	@BeforeTest
    public void startReport() {
        logger.info("Report Setup in each Test");
        ExtentSparkReporter spark = new ExtentSparkReporter("./reports/Extentreport.html");
        extent = new ExtentReports();
        extent.attachReporter(spark);
        spark.config().setTheme(Theme.DARK);
        spark.config().setDocumentTitle("MyReport");
        spark.config().setReportName("Test Report");
        spark.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
    }

	private String captureScreenshot(String testName, String directoryPath) {
	    String screenshotPath = "";
	    LocalDateTime currentTime = LocalDateTime.now();
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
	    String formattedTime = currentTime.format(formatter);
	    try {
	        TakesScreenshot ts = (TakesScreenshot) driver;
	        File screenshotFile = ts.getScreenshotAs(OutputType.FILE);

	        // Ensure the directory exists
	        File directory = new File(directoryPath);
	        if (!directory.exists()) {
	            directory.mkdirs(); // Create the directory if it doesn't exist
	        }

	        // Construct the correct relative path
	        screenshotPath = directoryPath + File.separator + testName + formattedTime + ".png";
	        FileUtils.copyFile(screenshotFile, new File(screenshotPath));

	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    return screenshotPath;
	}

	public void getResult(ITestResult result) {
	    logger.info("Report Result in each Test");
	    String path;
	    if (result.getStatus() == ITestResult.FAILURE) {
	        test.log(Status.FAIL, result.getThrowable());
	        System.out.println(result.getThrowable());
	        path = captureScreenshot(result.getName(), "./reports/screenshots");
	        path = path.replace("./reports/", "./");
	        test.log(Status.FAIL, "Test Case Failed");
	        test.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + " - Test Case Failed", ExtentColor.RED));
	        test.fail("Screenshot below: " + test.addScreenCaptureFromPath(path));
	    } else if (result.getStatus() == ITestResult.SUCCESS) {
	        test.log(Status.PASS, result.getThrowable());
	        path = captureScreenshot(result.getName(), "./reports/screenshots");
	        path = path.replace("./reports/", "./");
	        test.log(Status.PASS, "Test Case Passed");
	        test.log(Status.PASS, MarkupHelper.createLabel(result.getName() + " - Test Case Passed", ExtentColor.GREEN));
	        test.pass("Screenshot below: " + test.addScreenCaptureFromPath(path));
	    } else {
	        test.log(Status.SKIP, result.getTestName());
	    }
	}

    private String extractAndSetTestCategory(Method method) {
        CustomTest customTestAnnotation = method.getAnnotation(CustomTest.class);
        if (customTestAnnotation != null) {
            String category = customTestAnnotation.category();
            // Dynamically set test category here if needed
            return customTestAnnotation.category();
        }
		return null;
    }
    private String extractAndSetTestName(Method method) {
            System.out.println("Test Name: " + method.getName());
            return method.getName();
    }
    private String extractAndSetTestAuthor(Method method) {
        CustomTest customTestAnnotation = method.getAnnotation(CustomTest.class);
        if (customTestAnnotation != null) {
            String author = customTestAnnotation.author();
            // Dynamically set test author here if needed
            return author;
        }
		return null;
    }
    private String extractAndSetTestDescription(Method method) {
        Test testAnnotation = method.getAnnotation(Test.class);
        if (testAnnotation != null && !testAnnotation.description().isEmpty()) {
            String description = testAnnotation.description();
            // Dynamically set test description here if needed
            return "<b style=\"color:yellow;\"><i>" +testAnnotation.description()+ "</i></b>";
        }
		return null;
    }
   
    @AfterTest
    public void endReport() {
        extent.flush();
//        GmailReportSender reportSender=new GmailReportSender();
//        reportSender.sendReport(Arrays.asList("sathyamudili07@gmail.com"));
    }
    
    @AfterMethod
    public void tearDown(ITestResult result) throws Exception {
    	getResult(result);
        driver.quit();
    }
    
    public static void highlightElement(By locator, boolean result) {
        try {
        	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(locator));
            String color = result ? "green" : "red";
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].style.border='5px solid " + color + "'", element);
        } catch (StaleElementReferenceException e) {
            // Re-find the element and retry highlighting
            WebElement element = driver.findElement(locator);
            String color = result ? "green" : "red";
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].style.border='5px solid " + color + "'", element);
        }
    }

    public static void click(By locator) {
    	driver.findElement(locator).click();
    	test.log(Status.INFO, "Clicked the button or element"+" "+locator);
    }
	protected static void click(WebElement element) {
		element.click();
		test.log(Status.INFO, "Clicked the button or element"+" "+element);
	}
	public static void fill(By locator,String input) {
		driver.findElement(locator).sendKeys(input);
		test.log(Status.INFO, "Entered the input value of "+locator+" as "+input);
	}
	public void selectOptionByText(String optionText,By locator) {
		Select dropdown =new Select(driver.findElement(locator));
		dropdown.selectByVisibleText(optionText);
		test.log(Status.INFO, "Selected the value"+" "+optionText+" from "+locator);
	}
	public void selectOptionByValue(String value,By locator) {
		Select dropdown =new Select(driver.findElement(locator));
		dropdown.selectByValue(value);
		test.log(Status.INFO, "Selected the value"+" "+value+" from "+locator);
	}
	public void selectOptionByIndex(int index,By locator) {
		Select dropdown =new Select(driver.findElement(locator));
		dropdown.selectByIndex(index);
		test.log(Status.INFO, "Selected the value of index"+" "+index+" from "+locator);
	}
	public static void clear(By locator) {
    	driver.findElement(locator).clear();
    	test.log(Status.INFO, "Cleared the input value of"+" "+locator);
    }
}
