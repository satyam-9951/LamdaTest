package unqork.tests;

import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import unqork.base.Base;
import unqork.pages.AdminPage;
import unqork.pages.ForgotPasswordPage;
import unqork.pages.HomePage;
import unqork.pages.LoginPage;
import unqork.pages.QuotePage;
import io.github.bonigarcia.wdm.WebDriverManager;


public class UnqorkTest extends Base {
	private static final Logger logger = LogManager.getLogger(UnqorkTest.class);
	
	
	@Test(priority = 1,description="Verify quotepage header is visible or not")
	@CustomTest(author = "Sathya", category = "Sanity",story="deeh-122 deeh-112",sprint="101")
	public void checkingQuotePageHeaderVisibility() {
		assertTrue(quotePage.checkHeaderVisibility(),"verified the quote page header is visible");
		String username = jsonObject.get("username").getAsString();
		String password = jsonObject.get("password").getAsString();
		System.out.println("this from test data");
		System.out.println(username+" and  "+password);
	}
	
	@Test(priority = 2,description="verify daily trip is selected")
	@CustomTest(author = "Aravinth", category = "Smoke",story="deeh-122 deeh-112",sprint="107")
	public void checkingDailyTripIsSelected() {
		quotePage.selectDailyTrip();
		assertTrue(quotePage.checkDailyTripIsSelected(),"verified daily trip is selected");
	}
	
	@Test(priority = 3,description="validate the selected option is correct")
	@CustomTest(author = "Pradeep", category = "Regression",story="deeh-112",sprint="109")
	public void checkingDesiredPlaceIsSelected() {
		quotePage.selectVisitingPlace("Araku");
	    assertTrue(quotePage.verifyThePlaceSelected("Araku"),"validate the selected option is correct");
	}
	
	@Test(priority = 4,description="validate the selected option ")
	@CustomTest(author = "Pradeep", category = "Regression",story="deeh-122",sprint="110")
	public void checkingSelectedPlace() {
		quotePage.selectVisitingPlace("Araku");
	    assertTrue(quotePage.verifyThePlaceSelected("Ooty"),"validate the selected option is correct");
	}

}
