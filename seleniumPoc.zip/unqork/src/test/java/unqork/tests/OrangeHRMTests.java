//package unqork.tests;
//
//import org.openqa.selenium.By;
//import org.testng.Assert;
//import org.testng.annotations.Test;
//import io.qameta.allure.Description;
//import io.qameta.allure.Owner;
//import io.qameta.allure.Link;
//import io.qameta.allure.Issue;
//
//public class OrangeHRMTests extends BaseTest {
//
//    private final String baseUrl = "https://opensource-demo.orangehrmlive.com/";
//
//    @Test(priority = 1, description = "Verify login with valid credentials")
//    @Description("This test attempts to log into the website using a login and a password. Fails if any error happens.")
//    @Owner("John Doe")
//    @Link(name = "Website", url = "https://dev.example.com/")
//    @Issue("AUTH-123")
//    public void loginWithValidCredentials() {
//        driver.findElement(By.name("username")).sendKeys("Admin");
//        driver.findElement(By.name("password")).sendKeys("admin123");
//        driver.findElement(By.xpath("//button[@type='submit']")).click();
////        captureScreenshot("Login With Valid Credentials");
//
//        Assert.assertTrue(driver.findElement(By.xpath("//h6[text()='Dashboard']")).isDisplayed(),
//            "Dashboard should be visible after a successful login.");
//        Assert.assertTrue(true==false,"should be failed");
//    }
//
//    @Test(priority = 2, description = "Verify login with invalid credentials")
//    @Description("This test attempts to log into the website with invalid credentials and checks for error messages.")
//    @Owner("John Doe")
//    public void loginWithInvalidCredentials() {
//        driver.findElement(By.name("username")).sendKeys("invalid_user");
//        driver.findElement(By.name("password")).sendKeys("wrong_password");
//        driver.findElement(By.xpath("//button[@type='submit']")).click();
////        captureScreenshot("Login With Invalid Credentials");
//
//        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(text(), 'Invalid')]")).isDisplayed(),
//            "Error message should be visible for invalid credentials.");
//    }
//
//    @Test(priority = 3, description = "Verify logout functionality")
//    @Description("Logs out from the application and verifies successful redirection to the login page.")
//    @Owner("John Doe")
//    public void logoutTest() {
//        driver.findElement(By.name("username")).sendKeys("Admin");
//        driver.findElement(By.name("password")).sendKeys("admin123");
//        driver.findElement(By.xpath("//button[@type='submit']")).click();
////        captureScreenshot("Login Success");
//
//        driver.findElement(By.xpath("//i[@class='oxd-userdropdown-icon']")).click();
//        driver.findElement(By.xpath("//a[text()='Logout']")).click();
//
//        Assert.assertTrue(driver.findElement(By.xpath("//button[@type='submit']")).isDisplayed(),
//            "Login button should be visible after logout.");
////        captureScreenshot("Logout Success");
//    }
//}
