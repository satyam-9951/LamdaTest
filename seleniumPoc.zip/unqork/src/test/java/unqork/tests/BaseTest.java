//package unqork.tests;
//
//import io.qameta.allure.Attachment;
//import io.qameta.allure.Step;
//import org.openqa.selenium.*;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.testng.ITestContext;
//import org.testng.ITestResult;
//import org.testng.annotations.*;
//import io.github.bonigarcia.wdm.WebDriverManager;
//import java.io.File;
//import java.io.IOException;
//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.util.concurrent.TimeUnit;
//
//public class BaseTest {
//    protected WebDriver driver;
//    private static final Logger logger = LoggerFactory.getLogger(BaseTest.class);
//    private static final String ALLURE_RESULTS_DIR = "allure-results";  // Directory for allure results
//    private static final String SCREENSHOTS_DIR = "allure-results/screenshots";  // Directory to save screenshots
//    private final String baseUrl = "https://opensource-demo.orangehrmlive.com/";
//
//    @BeforeSuite
//    public void cleanAllureResults() {
//        logger.info("Cleaning Allure results directory...");
//        try {
//            // Clean Allure results
//            Files.walk(Paths.get(ALLURE_RESULTS_DIR))
//                    .map(Path::toFile)
//                    .forEach(File::delete);
//            // Clean screenshots directory
//            Files.walk(Paths.get(SCREENSHOTS_DIR))
//                    .map(Path::toFile)
//                    .forEach(File::delete);
//        } catch (Exception e) {
//            logger.error("Failed to clean Allure results directory", e);
//        }
//    }
//
//    @BeforeMethod
//    public void setUp(ITestContext context) {
//        logger.info("Initializing the WebDriver for Test: {}", context.getName());
//        WebDriverManager.chromedriver().setup();  // Using WebDriverManager to handle driver setup
//        driver = new ChromeDriver();
//        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//        driver.manage().window().maximize();
//        driver.get(baseUrl);
//    }
//
//    @AfterMethod
//    public void tearDown(ITestResult result) {
//        if (driver != null) {
//            // Capture and attach the screenshot after each test method (whether success or failure)
//            captureScreenshot(result);
//            driver.quit();
//        }
//    }
//
//    // Method to capture and attach screenshots to Allure report
//    @Attachment(value = "Screenshot - {0}", type = "image/png")
//    public byte[] captureScreenshot(ITestResult result) {
//        String testName = result.getMethod().getMethodName();
//        logger.info("Capturing screenshot for test: {}", testName);
//
//        // Ensure the screenshot directory exists
//        File screenshotDir = new File(SCREENSHOTS_DIR);
//        if (!screenshotDir.exists()) {
//            screenshotDir.mkdirs();  // Create the directory if it doesn't exist
//        }
//
//        // Capture the screenshot as a file
//        File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//
//        // Define the path where the screenshot will be saved
//        Path destinationPath = Paths.get(SCREENSHOTS_DIR, testName + ".png");
//        	
//        try {
//            // Copy the screenshot file to the specified directory
//            Files.copy(screenshotFile.toPath(), destinationPath);
//        } catch (IOException e) {
//            logger.error("Failed to save screenshot for test: {}", testName, e);
//        }
//
//        // Return the screenshot as bytes for attaching to Allure
//        return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
//    }
//
//    @Step("Navigate to URL: {0}")
//    public void navigateTo(String url) {
//        logger.info("Navigating to URL: {}", url);
//        driver.get(url);
//    }
//
//    @Step("Verify text equals: {0}")
//    public void verifyText(String actual, String expected) {
//        try {
//            logger.info("Verifying text: {} equals {}", actual, expected);
//            if (!actual.equals(expected)) {
//                throw new AssertionError("Expected: " + expected + ", but got: " + actual);
//            }
//        } catch (Exception e) {
//            logger.error("Error during assertion: {}", e.getMessage());
//            throw e;  // Rethrow to ensure test fails
//        }
//    }
//}
