package unqork.base;

import java.time.Duration;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class BasePage {
	private static final Logger logger = LogManager.getLogger(BasePage.class);
    public static ExtentReports extent;
    public static ExtentTest test;
	public static WebDriver driver;
	private WebDriverWait wait;
	// Ensure this is initialized

	public BasePage(WebDriver driver, ExtentTest test) {
        this.driver = driver;
        this.test = test;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
	
	public static void highlightElement(By locator, boolean result) {
        try {
        	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(locator));
            String color = result ? "green" : "red";
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].style.border='5px solid " + color + "'", element);
        } catch (StaleElementReferenceException e) {
            // Re-find the element and retry highlighting
            WebElement element = driver.findElement(locator);
            String color = result ? "green" : "red";
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].style.border='5px solid " + color + "'", element);
        }
    }

    public static void click(By locator) {
    	driver.findElement(locator).click();
    	test.log(Status.INFO, "Clicked the button or element"+" "+locator);
    }
	protected static void click(WebElement element) {
		element.click();
		test.log(Status.INFO, "Clicked the button or element"+" "+element);
	}
	public static void fill(By locator,String input) {
		driver.findElement(locator).sendKeys(input);
		test.log(Status.INFO, "Entered the input value of "+locator+" as "+input);
	}
	public void selectOptionByText(String optionText,By locator) {
		Select dropdown =new Select(driver.findElement(locator));
		dropdown.selectByVisibleText(optionText);
		test.log(Status.INFO, "Selected the value"+" "+optionText+" from "+locator);
	}
	public void selectOptionByValue(String value,By locator) {
		Select dropdown =new Select(driver.findElement(locator));
		dropdown.selectByValue(value);
		test.log(Status.INFO, "Selected the value"+" "+value+" from "+locator);
	}
	public void selectOptionByIndex(int index,By locator) {
		Select dropdown =new Select(driver.findElement(locator));
		dropdown.selectByIndex(index);
		test.log(Status.INFO, "Selected the value of index"+" "+index+" from "+locator);
	}
	public static void clear(By locator) {
    	driver.findElement(locator).clear();
    	test.log(Status.INFO, "Cleared the input value of"+" "+locator);
    }
}
