package unqork.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class GmailReportSender {
    
    public void sendReport(List<String> recipients) {
        String from = ""; //use your email here
        String appPassword = ""; // Use App Password here
        String folderPath = "C:\\Users\\SatyamNaiduMudili\\eclipse-workspace\\unqork\\reports"; // Path to the folder
        String zipFilePath = "C:\\Users\\SatyamNaiduMudili\\eclipse-workspace\\unqork\\reports.zip"; // Path for the ZIP file

        try {
            // Step 1: Compress the folder into a ZIP file
            zipFolder(folderPath, zipFilePath);

            // Step 2: Gmail SMTP server configuration
            Properties properties = new Properties();
            properties.put("mail.smtp.host", "smtp.gmail.com");
            properties.put("mail.smtp.port", "587");
            properties.put("mail.smtp.auth", "true");
            properties.put("mail.smtp.starttls.enable", "true");

            // Authenticate Gmail session
            Session session = Session.getInstance(properties, new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(from, appPassword);
                }
            });

            // Step 3: Create email message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            
            // Add multiple recipients
            for (String recipient : recipients) {
                message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
            }

            message.setSubject("Selenium Test Report");
            message.setText("Please find the attached Selenium test report.");

            // Attach the ZIP file
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.addHeaderLine("Here the selenium execution report");
            messageBodyPart.attachFile(zipFilePath);
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);

            message.setContent(multipart);

            // Step 4: Send email
            Transport.send(message);
            System.out.println("Test report sent successfully to multiple recipients via Gmail!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Method to zip a folder
    private static void zipFolder(String folderPath, String zipFilePath) throws Exception {
        File folder = new File(folderPath);
        if (!folder.exists() || !folder.isDirectory()) {
            throw new IllegalArgumentException("Invalid folder path: " + folderPath);
        }

        try (FileOutputStream fos = new FileOutputStream(zipFilePath);
             ZipOutputStream zos = new ZipOutputStream(fos)) {
            zipFiles(folder, folder.getName(), zos);
        }
    }

    // Recursive method to add files to the ZIP output stream
    private static void zipFiles(File fileToZip, String fileName, ZipOutputStream zos) throws Exception {
        if (fileToZip.isHidden()) {
            return;
        }

        if (fileToZip.isDirectory()) {
            if (!fileName.endsWith("/")) {
                fileName += "/";
            }
            zos.putNextEntry(new ZipEntry(fileName));
            zos.closeEntry();

            for (File childFile : fileToZip.listFiles()) {
                zipFiles(childFile, fileName + childFile.getName(), zos);
            }
            return;
        }

        try (FileInputStream fis = new FileInputStream(fileToZip)) {
            zos.putNextEntry(new ZipEntry(fileName));
            byte[] buffer = new byte[1024];
            int length;
            while ((length = fis.read(buffer)) >= 0) {
                zos.write(buffer, 0, length);
            }
            zos.closeEntry();
        }
    }

}
