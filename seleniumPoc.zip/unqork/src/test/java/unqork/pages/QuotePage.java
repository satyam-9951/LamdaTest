package unqork.pages;

import java.time.Duration;
import java.util.Arrays;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import unqork.base.Base;

public class QuotePage extends Base{
	private WebDriver driver;
	
	public By quotePageHeader=By.xpath("//center[normalize-space()='Travel Insurance Plan']");
	public By tripTypeHeader=By.xpath("//div[@id='tripType-group-label']");
	public By dailyTripLabel=By.xpath("//label[@for='tripType-Basic Plan']");
	public By monthlyTripLabel=By.xpath("//span[normalize-space()='Monthly Trip']");
	public By annualTripLabel=By.xpath("//span[normalize-space()='Annual Trip']");
	public By annualTripCheckBox=By.xpath("//input[@id='tripType-Preferred Plan']");
	public By monthlyTripCheckBox=By.xpath("//input[@id='tripType-Essential Plan']");
	public By dailyTripCheckBox=By.xpath("//input[@id='tripType-Basic Plan']");
	public By adultsLabel=By.xpath("//label[@id='adultsLabel']");
	public By childrenLabel=By.xpath("//label[@id='childrenLabel']");
	public By visitingLabel=By.xpath("//label[@id='visitingLabel']");
	public By startDateLabel=By.xpath("//label[@for='dailyStartDate']");
	public By endDateLabel=By.xpath("//label[@for='dailyEndDate']");
	public By nextBtn=By.xpath("//button[@id='nav-next-btn']");
	public By placeDropDown=By.xpath("//select[@id='visiting']");
	
	public QuotePage(WebDriver driver) {
		this.driver=driver;
	}
	
	public boolean checkHeaderVisibility() {
		boolean result=driver.findElement(quotePageHeader).isDisplayed();
		highlightElement(placeDropDown,result);
		System.out.println(result);
		return result;
	}
	public void selectDailyTrip() {
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(dailyTripLabel));
	    click(element);
	    
	}

	public boolean checkDailyTripIsSelected() {
		boolean result=driver.findElement(dailyTripCheckBox).isSelected();
		highlightElement(dailyTripCheckBox,result);
		return result;
	}
	public void selectVisitingPlace(String option) {;
		selectOptionByText(option, placeDropDown);
	}
	public boolean verifyThePlaceSelected(String option) {
		Select select = new Select(driver.findElement(placeDropDown));
		WebElement selectedOption = select.getFirstSelectedOption();
		String defaultItem = selectedOption.getText();
		boolean result=defaultItem.equals(option);
		highlightElement(placeDropDown,result);
		return result;
	}
}
